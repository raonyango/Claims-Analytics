package com.analytics.client.place;

import net.customware.gwt.presenter.client.EventBus;
import net.customware.gwt.presenter.client.place.DefaultPlaceManager;
import net.customware.gwt.presenter.client.place.TokenFormatter;

import com.google.inject.Inject;

public class MajiPlaceManager extends DefaultPlaceManager {

	@Inject
	public MajiPlaceManager(EventBus eventbus,
			TokenFormatter tokenformatter, BillPlace billplace) {
		
		super(eventbus, tokenformatter, billplace);
		
	}
}
