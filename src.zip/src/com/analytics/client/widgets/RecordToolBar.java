package com.analytics.client.widgets;

import com.analytics.shared.properties.MajiCSS;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.MenuItemSeparator;
import com.smartgwt.client.widgets.toolbar.ToolStrip;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;
import com.smartgwt.client.widgets.toolbar.ToolStripMenuButton;

public class RecordToolBar extends HLayout {
	protected final ToolStrip toolstrip;
	public static final String TOOLSTRIP_HEIGHT = "25px";
	public static final String TOOLSTRIP_WIDTH = "*";
	private static final int DEFAULT_SHADOW_DEPTH = 3;
	private static final String SEPARATOR = "separator";
	public static final String DELIMITER = ",";

	public RecordToolBar() {
		super();

		this.setStyleName(MajiCSS.record_toolbar);
		 this.setStyleName("crm-Entity-ToolBar");
		this.setHeight(ToolBar.TOOLBAR_HEIGHT);

		toolstrip = new ToolStrip();
		toolstrip.setStyleName(MajiCSS.record_toolstrip);
		 toolstrip.setStyleName("crm-Entity-ToolStrip");
		toolstrip.setHeight(ToolBar.TOOLBAR_HEIGHT);
		toolstrip.setWidth(ToolBar.TOOLSTRIP_WIDTH);

		/*Img logo = new Img("toolbar/logo.png", 48, 36);
		logo.setStyleName("crm-Entity-ToolBar-Logo");
		toolstrip.addChild(logo);*/

		this.addMember(toolstrip);
	}

	public ToolStripButton addButton(String icon, String tooltip,
			ClickHandler clickHandler) {
		ToolStripButton button = new ToolStripButton();
		button.setIcon(icon);
		button.setTooltip(tooltip);

		if (clickHandler != null)
			button.addClickHandler(clickHandler);

		toolstrip.addButton(button);

		return button;
	}

	public ToolStripButton addButton(String icon, String title, String tooltip,
			ClickHandler clickHandler) {
		ToolStripButton button = new ToolStripButton();
		button.setIcon(icon);
		button.setTitle(title);
		button.setTooltip(tooltip);

		if (clickHandler != null)
			button.addClickHandler(clickHandler);

		toolstrip.addButton(button);

		return button;
	}
	
	public ToolStripMenuButton addMenuButton(String title,
			String menuItemNames,
			com.smartgwt.client.widgets.menu.events.ClickHandler clickHandler) {

		ToolStripMenuButton button = new ToolStripMenuButton(title, addMenu(
				menuItemNames, clickHandler));
		// button.setWidth(100);

		toolstrip.addMenuButton(button);

		return button;
	}

	public Menu addMenu(String menuItemNames,
			com.smartgwt.client.widgets.menu.events.ClickHandler clickHandler) {

		// initialise the new menu
		Menu menu = new Menu();
		// menu.setTitle(menuName);
		menu.setShowShadow(true);
		menu.setShadowDepth(DEFAULT_SHADOW_DEPTH);
		// menu.setWidth(width);

		// create an array of menu item names
		String[] menuItems = process(menuItemNames);

		for (int i = 0; i < menuItems.length; i++) {
			// remove any whitespace
			String menuItemName = menuItems[i].replaceAll("\\W", "");

			if (menuItemName.contentEquals(SEPARATOR)) {
				MenuItemSeparator separator = new MenuItemSeparator();
				menu.addItem(separator);
				continue;
			}

			MenuItem menuItem = new MenuItem(menuItems[i]);
			if (clickHandler != null) {
				menuItem.addClickHandler(clickHandler);
			}

			menu.addItem(menuItem);
		}

		return menu;
	}
	
	public static String[] process(String line) {
		return line.split(DELIMITER);
	}

	public void addSeparator() {
		toolstrip.addSeparator();
	}
}
