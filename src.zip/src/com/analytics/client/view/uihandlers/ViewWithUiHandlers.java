package com.analytics.client.view.uihandlers;

public abstract class ViewWithUiHandlers<T extends UiHandlers>{ //extends ViewImpl	implements HasUiHandlers<T> {
	private T uiHandlers;

	/**
	 * Access the {@link UiHandlers} associated with this {@link View}.
	 * <p>
	 * <b>Important!</b> Never call {@link #getUiHandlers()} inside your
	 * constructor since the {@link UiHandlers} are not yet set.
	 * 
	 * @return The {@link UiHandlers}, or {@code null} if they are not yet set.
	 */
	protected T getUiHandlers() {
		return uiHandlers;
	}

	//@Override
	public void setUiHandlers(T uiHandlers) {
		this.uiHandlers = uiHandlers;
	}
}
