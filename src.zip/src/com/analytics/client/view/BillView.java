package com.analytics.client.view;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import com.allen_sauer.gwt.log.client.Log;
import com.analytics.client.presenter.BillPresenter;
import com.analytics.client.view.uihandlers.BillViewUiHandlers;
import com.analytics.client.view.uihandlers.ViewWithUiHandlers;
import com.analytics.client.widgets.ContextListGrid;
import com.analytics.client.widgets.RecordToolBar;
import com.analytics.client.widgets.StatusBar;
import com.analytics.client.widgets.ToolBar;
import com.analytics.shared.ibatis.beans.Claim;
import com.analytics.shared.properties.MajiCSS;
import com.analytics.shared.properties.MajiMessages;
import com.google.gwt.i18n.client.LocaleInfo;
import com.google.inject.Inject;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.ButtonItem;
import com.smartgwt.client.widgets.form.fields.DateItem;
import com.smartgwt.client.widgets.form.fields.PickerIcon;
import com.smartgwt.client.widgets.form.fields.SectionItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.validator.CustomValidator;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.Layout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class BillView extends ViewWithUiHandlers<BillViewUiHandlers> implements
		BillPresenter.IBillViewDisplay {

	private static final String CONTEXT_AREA_WIDTH = "100%";
	private Integer recordid;

	private final RecordToolBar toolbar, form_tbar, print_tbar;
	private final ContextListGrid listgrid;
	private final StatusBar statusbar;

	private VLayout maincontainer;
	// private ToolStripButton printpreviewbtn;

	private int numberofelements;
	private int numberselected;
	private int pageNumber;

	private MajiMessages messages;
	
	private static final String METER_READING = "meter_reading";
	private static final String PREV_METER_READING = "prev_meter_reading";
	private static final String UNITS_CONSUMED = "unitsconsumed";
	private static final String UNIT_CHARGE = "unitcharge";
	private static final String MONTH = "month";
	private static final String YEAR = "year";

	private static final String STATUS = "status";
	private static final String HOUSE_UNIT = "house_unit";
	private static final String CREATED_ON = "created_on";
	private static final String DUE_DATE = "due_date";
	private static final String BILLING_DATE = "billing_date";
	private static final String CANCEL_BTN = "cancel_btn";
	private static final String TOTAL_BILL_AMOUNT = "total_bill";
	private static final String BILL_ID = "bill_id";
	private static final String PRINT_OPTIONS = "print_options";
	private static final String PRINT_BTN = "print_btn";
	private static final String FORM_SECTION = "form_section";

	protected int bill_id;
	protected TextItem meter_reading;
	protected TextItem unitsconsumed;
	protected TextItem total_amount, prev_meter_reading, bill_id_txt;
	protected SelectItem month, year, status, unitcharge, print_options;
	protected SectionItem bill_section;

	protected DateItem duedate, billingdate;
	protected TextItem created_on;
	protected SelectItem houseunit;

	protected PickerIcon unit_charge_pki, house_unit_pki;
	protected DynamicForm form;

	protected DataSource status_ds, unit_ds, charge_ds;

	protected ButtonItem printbtn, cancelbtn;
	protected ListGrid pickListProperties;
	protected ListGridField unitField, tenantField;
	protected MyFloatValidator meterValidator;
	Claim bill;
	private ToolStripButton save_btn, save_close_btn, update_btn, print_btn;

	@Inject
	public BillView(RecordToolBar toolbar, RecordToolBar form_toolbar,
			RecordToolBar print_tbar, DynamicForm iform, BillListGrid listgrid,
			StatusBar statusbar, MajiMessages messages) {
		this.toolbar = toolbar;
		this.listgrid = listgrid;
		this.statusbar = statusbar;
		this.messages = messages;
		this.form_tbar = form_toolbar;
		this.form = iform;
		this.print_tbar = print_tbar;

		this.numberofelements = 50;
		this.numberselected = 0;
		pageNumber = 1;

		maincontainer = new VLayout();

		// initialise the View's layout container
		maincontainer.setStyleName(MajiCSS.context_area);
		maincontainer.setWidth(CONTEXT_AREA_WIDTH);

		// add the Tool Bar, List Grid, and Status Bar to the View's layout
		// container
		maincontainer.addMember(this.toolbar);
		maincontainer.addMember(this.listgrid);
		maincontainer.addMember(this.statusbar);

		bindCustomUiHandlers();

		recordid = -1;
	}

	protected void bindCustomUiHandlers() {
		// register the ListGird handlers
		listgrid.addSelectionChangedHandler(new SelectionChangedHandler() {
			@Override
			public void onSelectionChanged(SelectionEvent event) {

				ListGridRecord[] records = event.getSelection();

				numberselected = records.length;

				String selectedLabel = messages.selected(numberselected,
						numberofelements);
				statusbar.getSelectedLabel().setContents(selectedLabel);

			}
		});

		listgrid.addRecordClickHandler(new RecordClickHandler() {

			@Override
			public void onRecordClick(RecordClickEvent event) {
				Record record = event.getRecord();
				recordid = record.getAttributeAsInt(BillRecord.BILL_ID);

				if (maincontainer.hasMember(form)) {
					show_update_form(recordid);
				}
			}
		});

		// register the ListGird handlers
		listgrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				Record record = event.getRecord();
				recordid = record.getAttributeAsInt(BillRecord.BILL_ID);

				show_update_form(recordid);
			}
		});

		// initialise the ToolBar and register its handlers
		initToolBar();

		// initialise the StatusBar and register its handlers
		initStatusBar();
	}

	protected void show_update_form(Integer recordid2) {
		if (getUiHandlers() != null) {
			getUiHandlers().onRecordDoubleClicked(recordid);

			//--build_add_form();

			if (maincontainer.hasMember(form_tbar)) {
				maincontainer.removeMember(form_tbar);
			}

			if (maincontainer.hasMember(form)) {
				maincontainer.removeMember(form);
			}

			if (maincontainer.hasMember(print_tbar)) {
				maincontainer.removeMember(print_tbar);
				// form = null;
			}

			if (!maincontainer.hasMember(form_tbar)) {
				maincontainer.addMember(form_tbar);
			}

			if (!maincontainer.hasMember(form)) {
				maincontainer.addMember(form);
				// form.show();
			}

			print_btn.disable();
			save_close_btn.disable();

		}
	}

	protected void initToolBar() {
		// ToolStripButton save_btn = new ToolStripButton(ToolBar.SAVE_BUTTON,
		// tconstants.savebtn_caption());
		
		print_tbar.addButton(ToolBar.CANCEL_BUTTON,
				"Cancel", "Cancel",
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							maincontainer.removeMember(print_tbar);
							maincontainer.removeMember(form);
							// form = null;
						}
					}
				});

		save_btn = form_tbar.addButton(ToolBar.SAVE_BUTTON,
				"Save", "Save",
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (validate_form()) {
							//save_new_bill();

							//resetForm();
						}
					}
				});
		save_btn.disable();
				
		update_btn = form_tbar.addButton(ToolBar.UPDATE_BUTTON,
				"Update", "Update",
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						
					}
				});
		update_btn.disable();
		form_tbar.addSeparator();
		
		form_tbar.addButton(ToolBar.CANCEL_BUTTON,
				"Cancel", "Cancel",
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							maincontainer.removeMember(form_tbar);
							maincontainer.removeMember(form);
							// form = null;
						}
						
					}
				});

		toolbar.addButton(ToolBar.REFRESH_BUTTON,
				"Refresh",
				"Refresh", new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							// maincontainer.disable();
							getUiHandlers().onRefreshButtonClicked();
						}
					}
				});

		toolbar.addSeparator();

		toolbar.addButton(ToolBar.NEW_ACCOUNT_BUTTON,
				"New", "New",
				new ClickHandler() {
					public void onClick(ClickEvent event) {

						if (getUiHandlers() != null) {
							getUiHandlers().onNewButtonClicked();

							//build_add_form();
						}

						if (maincontainer.hasMember(form_tbar)) {
							maincontainer.removeMember(form_tbar);
							// form = null;
						}
						
						if (maincontainer.hasMember(print_tbar)) {
							maincontainer.removeMember(print_tbar);
							// form = null;
						}

						if (maincontainer.hasMember(form)) {
							maincontainer.removeMember(form);
							// form = null;
						}
						maincontainer.addMember(form_tbar);
						maincontainer.addMember(form);

						update_btn.disable();
					}
				});

		toolbar.addSeparator();

		toolbar.addButton(ToolBar.PRINT_PREVIEW_BUTTON,
				"Print",
				"Print", new ClickHandler() {

					@Override
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							build_print_form();

							if (maincontainer.hasMember(form_tbar)) {
								maincontainer.removeMember(form_tbar);
								// form = null;
							}

							if (maincontainer.hasMember(print_tbar)) {
								maincontainer.removeMember(print_tbar);
								// form = null;
							}

							if (maincontainer.hasMember(form)) {
								maincontainer.removeMember(form);
								// form = null;
							}

							maincontainer.addMember(print_tbar);
							maincontainer.addMember(form);
						}
					}
				});

		// printpreviewbtn.disable();

	}

	class DueDateValidator extends CustomValidator {

		@Override
		protected boolean condition(Object value) {
			if (duedate.getValue() == null) {
				// err = "Due date is required.";
				// setErrorMessage("Date is required");
				return false;
			} else {
				try {
					Date today = new Date();
					Date d = (Date) duedate.getValue();

					if (d.compareTo(today) < 0) {
						setErrorMessage("Must be a date equal to or after date today.");
						d = null;

						return false;
					} else {
						d = null;
						return true;
					}

				} catch (Exception e) {
					// err = "Invalid Due Date.";
					setErrorMessage("Invalid date value.");
					Log.info("validate err...................."
							+ e.getMessage());
					return false;
				}
			}
		}
	}

	class HouseUnitValidator extends CustomValidator {

		@Override
		protected boolean condition(Object value) {
			if (houseunit.getValue() == null) {
				// err = "House Unit is required.";
				setErrorMessage("House unit is required");
				return false;
			} else if (Integer.parseInt(houseunit.getValue().toString()) < 1) {
				// err = "House Unit is required.";
				setErrorMessage("House unit is required");
				return false;
			} else {
				return true;
			}
		}
	}

	class MyFloatValidator extends CustomValidator {

		@Override
		protected boolean condition(Object value) {
			if (meter_reading.getValue() == null) {
				// err = "House Unit is required.";
				setErrorMessage("Meter Reading is required");
				return false;
			} else {
				try {
					Double temp = Double.parseDouble(meter_reading.getValue()
							.toString());

					if (temp < 0) {
						setErrorMessage("Meter Reading cannot be a negative value.");
						return false;
					}

					return true;
				} catch (Exception e) {
					setErrorMessage("Invalid Meter Reading Value");
					return false;
				}
			}
		}
	}

	protected boolean validate_form() {
		/*
		 * String err = null;
		 * 
		 * if(err == null && form.validate()){ return true; }else{
		 * SC.say("Validation Error",err); return false; }
		 */

		if (form.validate()) {
			if (Double.parseDouble(meter_reading.getValue().toString()) < Double
					.parseDouble(prev_meter_reading.getValue().toString())) {
				SC.say("Validation Error",
						"Current meter reading cannot be less that the previous meter reading");
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}

	}
	
	protected void initStatusBar() {

		// "0 of 50 selected"
		// statusbar.getSelectedLabel().setContents(Serendipity.getConstants().selectedLabel());

		statusbar.getResultSetFirstButton().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (getUiHandlers() != null) {
					getUiHandlers().onResultSetFirstButtonClicked();
				}
			}
		});

		statusbar.getResultSetPreviousButton().addClickHandler(
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							getUiHandlers().onResultSetPreviousButtonClicked();
						}
					}
				});

		// "Page 1"
		// statusbar.getPageNumberLabel().setContents(Serendipity.getConstants().pageNumberLabel());

		statusbar.getResultSetNextButton().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (getUiHandlers() != null) {
					getUiHandlers().onResultSetNextButtonClicked();
				}
			}
		});
	}

	@Override
	public void setResultSet(List<Claim> resultset) {
		// resultSet == null when there are no items in table
		if (resultset != null) {

			try {
				((BillListGrid) listgrid).setServicesResultSet(resultset);
			} catch (Exception e) {
				Log.info("ClaimsView.setResultSet Error...................."
						+ e.getMessage());
			}
		}
	}

	@Override
	public void refreshStatusBar() {
		// update Selected label e.g "0 of 50 selected"
		statusbar.getSelectedLabel().setContents(
				messages.selected(numberselected, numberofelements));
		// Log.info(numberofelements + "............REFRESH........");
		// update Page number label e.g "Page 1"
		statusbar.getPageNumberLabel().setContents(messages.page(pageNumber));
	}

	@Override
	public void setPageNumber(int pagenumber) {
		this.pageNumber = pagenumber;
	}

	@Override
	public void setNumberSelected(int numberselected) {
		this.numberselected = numberselected;
	}

	@Override
	public Layout asWidget() {
		return maincontainer;
	}

	@Override
	public StatusBar getStatusBar() {
		return statusbar;
	}

	@Override
	public void setNumberOfElements(int numberofelements) {
		this.numberofelements = numberofelements;

	}

	@SuppressWarnings("deprecation")
	public void build_print_form() {

		/*month = new SelectItem(MONTH, constants.month_lbl());
		month.setType("comboBox");
		month.setValueMap(getMonthsValueMap());
		// month.setDefaultToFirstOption(true);
		// month.setValue();
		month.setRequired(true);
		month.disable();

		Date d = new Date();
		year = new SelectItem(YEAR, constants.year_lbl());
		year.setType("comboBox");
		year.setValueMap(getYearsValueMap());
		// year.setDefaultToFirstOption(true);
		year.setDefaultValue(String.valueOf(d.getYear() + 1900));
		year.setRequired(true);
		year.disable();

		print_options = new SelectItem(PRINT_OPTIONS,
				constants.print_options_lbl());
		print_options.setType("comboBox");
		print_options.setRequired(true);
		print_options.setValueMap(getPrintOptionsValueMap());
		print_options.addChangeHandler(new ChangeHandler() {

			@Override
			public void onChange(ChangeEvent event) {
				if (Integer.parseInt(event.getValue().toString()) == 3
						|| Integer.parseInt(event.getValue().toString()) == 4) {
					month.enable();
					year.enable();
				} else {
					month.disable();
					year.disable();
				}

				print_btn.enable();
			}
		});

		bill_section = new SectionItem(FORM_SECTION);
		bill_section.setDefaultValue(constants.print_bills_section());
		bill_section.setItemIds("rowSpacer1", PRINT_OPTIONS, "rowSpacer2",
				MONTH,  "rowSpacer3", YEAR, "rowSpacer4");

		RowSpacerItem rowSpacer1 = new RowSpacerItem("rowSpacer1");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer2 = new RowSpacerItem("rowSpacer2");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer3 = new RowSpacerItem("rowSpacer3");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer4 = new RowSpacerItem("rowSpacer4");
		rowSpacer1.setStartRow(false);

		// form = new DynamicForm();
		// generalForm.setWidth100();
		form.setMargin(2);
		form.setNumCols(2);
		form.setCellPadding(2);
		form.setAutoFocus(false);
		form.setWrapItemTitles(false);
		form.setWidth("100%");

		// no ":" after the field name
		form.setTitleSuffix(" ");
		form.setRequiredTitleSuffix("*");
		form.setFields(bill_section, rowSpacer1, print_options, rowSpacer2,
				month,  rowSpacer3, year, rowSpacer4);
*/
	}

	private LinkedHashMap<String, String> getPrintOptionsValueMap() {
		LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();

		hm.put("1", "Print All");
		hm.put("2", "Print All Pending");
		hm.put("3", "Print All In Month");
		hm.put("4", "Print Pending In Month");

		return hm;
	}

	@SuppressWarnings("deprecation")
	private LinkedHashMap<String, String> getMonthsValueMap() {

		LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();

		int ctr = 0;
		Date d = new Date();

		String[] months = LocaleInfo.getCurrentLocale().getDateTimeFormatInfo()
				.monthsFull();

		for (String s : months) {
			hm.put(s, s);
			if (ctr == d.getMonth()) {
				month.setValue(s);
			}
			ctr++;
		}

		return hm;
	}

	@SuppressWarnings("deprecation")
	private LinkedHashMap<String, String> getYearsValueMap() {

		LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();
		// int ctr = 0;
		Date d = new Date();

		hm.put(String.valueOf(d.getYear() + 1900 - 1),
				String.valueOf(d.getYear() + 1900 - 1));
		hm.put(String.valueOf(d.getYear() + 1900),
				String.valueOf(d.getYear() + 1900));
		hm.put(String.valueOf(d.getYear() + 1900 + 1),
				String.valueOf(d.getYear() + 1900 + 1));

		return hm;
	}

	@Override
	public void setSaveNewSuccess() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setUpdateSuccess() {
		maincontainer.removeMember(form_tbar);
		maincontainer.removeMember(form);
		SC.say("Update successful");
	}

}