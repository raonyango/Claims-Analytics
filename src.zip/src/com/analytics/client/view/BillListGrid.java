package com.analytics.client.view;

import java.util.List;

import net.customware.gwt.presenter.client.EventBus;

import com.allen_sauer.gwt.log.client.Log;
import com.analytics.client.widgets.ContextListGrid;
import com.analytics.shared.ibatis.beans.Claim;
import com.google.inject.Inject;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ExpansionMode;
import com.smartgwt.client.types.ListGridFieldType;
import com.smartgwt.client.widgets.Button;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class BillListGrid extends ContextListGrid {
	private static final String SERVICE_ICON = "dashboard";

	private static final int BILL_NUM_COLUMN_WIDTH = 110;
	private static final int STRING_COLUMN_WIDTH = 110;
	private static final int DATE_COLUMN_WIDTH = 90; // 220
	private static final int NUMERIC_COLUMN_WIDTH = 90; // 220
	
	private EventBus eventbus;
	//private MajiStrings constants;

	@Inject
	public BillListGrid(EventBus eventbus) {
		super();
		this.eventbus = eventbus;
		//this.constants = constants;
		this.setCanExpandRecords(true);
		this.setExpansionMode(ExpansionMode.RELATED);// DETAIL_FIELD);
		// this.setDetailField(BillRecord.SERVICE_ID);
		this.setShowRecordComponents(true);
		this.setShowRecordComponentsByCell(true);
		// this.setHiliteProperty(BillRecord.SERVICE_HILITE);
		this.setEmptyMessage("No record found");

		// initialise the List Grid fields
		ListGridField iconfield = new ListGridField(BillRecord.ICON,
				BillRecord.ICON_DISPLAY_NAME, ICON_COLUMN_WIDTH);
		iconfield.setImageSize(16);
		iconfield.setAlign(Alignment.CENTER);
		iconfield.setType(ListGridFieldType.IMAGE);
		iconfield.setImageURLPrefix(URL_PREFIX);
		iconfield.setImageURLSuffix(URL_SUFFIX);

		/*ListGridField bill_number_field = new ListGridField(
				BillRecord.BILL_NUMBER, constants.bill_number_lbl(),
				BILL_NUM_COLUMN_WIDTH);

		ListGridField bill_month_field = new ListGridField(BillRecord.MONTH,
				constants.bill_month_lbl(), STRING_COLUMN_WIDTH);

		ListGridField bill_year_field = new ListGridField(BillRecord.YEAR,
				constants.bill_year_lbl(), NUMERIC_COLUMN_WIDTH);

		ListGridField meter_reading_field = new ListGridField(
				BillRecord.METERREADING, constants.grd_meter_reading_lbl(),
				BILL_NUM_COLUMN_WIDTH);

		ListGridField units_consumed_field = new ListGridField(
				BillRecord.UNITS, constants.units_consumed_lbl(),
				BILL_NUM_COLUMN_WIDTH);

		ListGridField unit_number_field = new ListGridField(
				BillRecord.UNIT_NUMBER, constants.unit_number_lbl(),
				NUMERIC_COLUMN_WIDTH);

		ListGridField charge_amount_field = new ListGridField(
				BillRecord.CHARGE_AMOUNT, constants.bill_charge_lbl(),
				BILL_NUM_COLUMN_WIDTH);

		ListGridField due_date_field = new ListGridField(BillRecord.DUE_DATE,
				constants.due_date_lbl(), DATE_COLUMN_WIDTH);
		due_date_field.setDateFormatter(DateDisplayFormat.TOSERIALIZEABLEDATE);

		ListGridField billing_date_field = new ListGridField(BillRecord.BILLING_DATE,
				constants.billing_date_lbl(), DATE_COLUMN_WIDTH);
		billing_date_field.setDateFormatter(DateDisplayFormat.TOSERIALIZEABLEDATE);

		
		ListGridField status_name_field = new ListGridField(
				BillRecord.STATUSNAME, constants.status_name_lbl(),
				NUMERIC_COLUMN_WIDTH);

		ListGridField created_on_field = new ListGridField(
				BillRecord.CREATED_ON, constants.person_created_on_lbl(),
				DATE_COLUMN_WIDTH);
		created_on_field.setCellAlign(Alignment.CENTER);

		created_on_field.setType(ListGridFieldType.TIME);
		created_on_field.setCellAlign(Alignment.CENTER);
		created_on_field
				.setDateFormatter(DateDisplayFormat.TOSERIALIZEABLEDATE);

		ListGridField empty_field = new ListGridField(EMPTY_FIELD,
				EMPTY_FIELD_DISPLAY_NAME);

		// set the fields into the List Grid
		this.setFields(new ListGridField[] { iconfield, bill_number_field,
				unit_number_field, bill_month_field, bill_year_field,
				meter_reading_field, units_consumed_field, charge_amount_field,
				due_date_field, billing_date_field,status_name_field, created_on_field,
				empty_field });*/
	}

	public void setServicesResultSet(List<Claim> bill_dtos) {
		try {

			int ctr = 0, ctr2 = 0;

			BillRecord[] billrecords = new BillRecord[bill_dtos.size()];
			ctr = 0;
			for (int i = 0; i < bill_dtos.size(); i++) {
				billrecords[ctr2] = createServiceRecord(bill_dtos.get(i));
				ctr2++;
			}

			// populate the List Grid
			this.setData(billrecords);

		} catch (Exception e) {
			Log.error("BillListGrid Error...................."
					+ e.getLocalizedMessage());
			Log.error(e.getStackTrace().toString());
		}
	}

	private BillRecord createServiceRecord(Claim bill_dto) {
		return new BillRecord(bill_dto);
	}

/*	@Override
	protected Canvas createRecordComponent(final ListGridRecord record,
			Integer colNum) {
		String field = this.getFieldName(colNum);
		IButton button = null;
		if (field.equals(BillRecord.UNIT_TELEPHONE)) {
			button = createGridButton("$");
			button.addClickHandler(new ClickHandler() {
				public void onClick(ClickEvent event) {
					eventbus.fireEvent(new ExpandEvent(record
							.getAttributeAsInt(BillRecord.UNIT_ID)));
				}
			});
			if (record.getAttributeAsBoolean(BillRecord.UNIT_TELEPHONE)) {
				button.disable();
			}
			return button;
		} else if (field.equals(BillRecord.CREATED_ON)) {
			button = createGridButton(">>");
			button.addClickHandler(new ClickHandler() {
				public void onClick(ClickEvent event) {
					eventbus.fireEvent(new ExpandEvent(record
							.getAttributeAsInt(BillRecord.UNIT_ID)));
				}
			});
			if (!record.getAttributeAsBoolean(BillRecord.CREATED_ON)) {
				button.disable();
			}
			return button;
		} else {
			return null;//
			createRecordComponent(record, colNum);
		}

		return createRecordComponent(record, colNum);
	}
*/
	private IButton createGridButton(String title) {
		IButton button = new IButton();
		button.setHeight(18);
		button.setWidth(35);
		// button.setIcon("flags/16/" + record.getAttribute("countryCode") +
		// ".png");
		button.setTitle(title);
		return button;
	}

	/*
	 * private static Hilite[] hilites = new Hilite[] { new Hilite() { { //
	 * setFieldNames(BillRecord.UNIT_NUMBER); setId(HILITE_BOUGHT_ID);
	 * setTextColor("#18187C"); setBackgroundColor("#DCDCDC"); setCriteria(new
	 * Criterion(BillRecord.UNIT_TELEPHONE, OperatorId.EQUALS, true)); //
	 * setCriteria(new AdvancedCriteria(OperatorId.AND, new Criterion[] // {new
	 * Criterion(BillRecord.UNIT_TELEPHONE, OperatorId.EQUALS, // true)})); //
	 * setCssText("font-weight:bolder;color:#18187C;background-color:#DCDCDC");
	 * } } };
	 */

	@Override
	protected Canvas getExpansionComponent(final ListGridRecord record) {
		final BillListGrid grid = this;
		BillRecord[] arr;
		ContextListGrid addonsgrid;

		VLayout layout = new VLayout(5);
		layout.setPadding(5);

		/*
		 * addonsgrid = new AddonsListGrid(constants, eventbus);
		 * addonsgrid.setWidth100();//500 addonsgrid.setHeight(134);//224
		 * addonsgrid.setCellHeight(22);
		 * addonsgrid.setHiliteProperty(BillRecord.SERVICE_HILITE);
		 * addonsgrid.setEmptyMessage(constants.no_addons_msg() + " " +
		 * constants.formsg() + " " +
		 * record.getAttributeAsString(BillRecord.UNIT_NUMBER));
		 * 
		 * arr =
		 * getRelatedAddons(record.getAttributeAsInt(BillRecord.SERVICE_ID));
		 * if(arr != null){ addonsgrid.setData(arr);
		 * addonsgrid.setHilites(hilites); }
		 * //addonsgrid.setDataSource(getRelatedDataSource(record));
		 * //addonsgrid.fetchRelatedData(record,
		 * SupplyCategoryXmlDS.getInstance());
		 * 
		 * layout.addMember(addonsgrid);
		 */
		HLayout hcontainer = new HLayout(10);
		hcontainer.setAlign(Alignment.CENTER);

		Button close_btn = new Button("Hide");
		close_btn.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				grid.collapseRecord(record);
			}
		});
		close_btn.setWidth(80);
		close_btn.setLayoutAlign(Alignment.RIGHT);
		hcontainer.addMember(close_btn);

		layout.addMember(hcontainer);

		return layout;
	}
}
