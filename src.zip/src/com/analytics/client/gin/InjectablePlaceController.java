package com.analytics.client.gin;

/*import com.google.gwt.place.shared.PlaceController;
import com.google.inject.Inject;
*/
public class InjectablePlaceController /*extends PlaceController */{

	/*@Inject
	public InjectablePlaceController(EventBus eventBus) {
		super(eventBus);
	}*/

}
