package com.analytics.server;

public class Manager {

}
