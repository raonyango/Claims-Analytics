package com.analytics.shared;

import java.io.Serializable;
import java.util.List;

public class StandardServerResponse implements Serializable{
	
	private static final long serialVersionUID = 2160914286526450744L;
	
	private List<? extends Serializable> listData = null;
	private boolean success = false;
	private int integerData = 0;
	private double doubleData = 0;
	private String stringData = null;
	private String errorData = null;
	private double[][] multiDimArrayData = null;
	private boolean processingcomplete = false;
	
	public StandardServerResponse(){
		
	}
	
	public List<? extends Serializable> getListData() {
		return listData;
	}
	
	public void setListData(List<? extends Serializable> listData) {
		this.listData = listData;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public int getIntegerData() {
		return integerData;
	}
	public void setIntegerData(int integerData) {
		this.integerData = integerData;
	}
	public String getStringData() {
		return stringData;
	}
	public void setStringData(String stringData) {
		this.stringData = stringData;
	}
	public String getErrorData() {
		return errorData;
	}
	public void setErrorData(String errorData) {
		this.errorData = errorData;
	}
	public double[][] getMultiDimArrayData() {
		return multiDimArrayData;
	}
	public void setMultiDimArrayData(double[][] multiDimArrayData) {
		this.multiDimArrayData = multiDimArrayData;
	}	
	public boolean isProcessingcomplete() {
		return processingcomplete;
	}
	public void setProcessingcomplete(boolean processingcomplete) {
		this.processingcomplete = processingcomplete;
	}

	public double getDoubleData() {
		return doubleData;
	}

	public void setDoubleData(double doubleData) {
		this.doubleData = doubleData;
	}	
}
