package com.analytics.client.presenter;

import java.util.List;

import net.customware.gwt.presenter.client.EventBus;
import net.customware.gwt.presenter.client.widget.WidgetDisplay;
import net.customware.gwt.presenter.client.widget.WidgetPresenter;

import com.allen_sauer.gwt.log.client.Log;
import com.analytics.client.GreetingServiceAsync;
import com.analytics.client.view.uihandlers.BillViewUiHandlers;
import com.analytics.client.view.uihandlers.HasUiHandlers;
import com.analytics.client.widgets.StatusBar;
import com.analytics.shared.ibatis.beans.Claim;
import com.google.gwt.user.client.Command;
import com.google.inject.Inject;
import com.smartgwt.client.widgets.layout.Layout;

public class BillPresenter extends
		WidgetPresenter<BillPresenter.IBillViewDisplay> implements
		BillViewUiHandlers {

	//private MajiStrings constants;
	private IBillViewDisplay display;
	private GreetingServiceAsync rpcservice;
	private EventBus eventbus;
	//private UserLoginData userdata;

	private int presenterwidth, presenterheight;
	private int maxresults;
	private int firstresult;
	private int pagenumber;
	private int numberofelements;

	private static final String HOST_FILENAME = "bill.html";
	private static final String ACTIVITY = "activity";
	private static final String NEW = "new";
	private static final String EDIT = "edit";
	private static final String PARAMETER_SEPERATOR = "&"; // GWTP "?"
	private static final String NAME = "_blank";
	private static final String FEATURES = "width=760, height=480";

	private List<Claim> claim_dtos;// , addon_dtos;
	
	public int getPresenterheight() {
		return presenterheight;
	}

	public int getPresenterwidth() {
		return presenterwidth;
	}

	public void setPresenterDimensions(int presenterheight, int presenterwidth) {
		this.presenterheight = presenterheight;
		this.presenterwidth = presenterwidth;
	}

	@Inject
	public BillPresenter(EventBus eventbus,
			IBillViewDisplay display, GreetingServiceAsync rpcService) {
		super(display, eventbus);
		this.display = display;
		rpcservice = rpcService;
		this.eventbus = eventbus;
		//this.constants = constants;

		display.setUiHandlers(this);
	}

	public interface IBillViewDisplay extends WidgetDisplay,
			HasUiHandlers<BillViewUiHandlers> {

		Layout asWidget();

		void setPageNumber(int pagenumber);

		void setNumberSelected(int numberselected);

		void refreshStatusBar();

		void setResultSet(List<Claim> resultset);

		void setNumberOfElements(int numberofelements);

		StatusBar getStatusBar();

		void setSaveNewSuccess();

		void setUpdateSuccess();

	}

	public void revealDisplay() {
		//this.userdata = userdata;
		if (claim_dtos == null) {
			retrieveGridRecords();
		} else {
			displayGridRecords();
		}

		revealDisplay();
	}

	@Override
	protected void onBind() {
		maxresults = 50; //MajiConstants.DEFAULT_MAX_GRID_RESULTS;
		firstresult = 0;
		pagenumber = 1;
		numberofelements = maxresults;

	}

	@Override
	protected void onRevealDisplay() {
		// TODO Auto-generated method stub
	}

	@Override
	protected void onUnbind() {
		// TODO Auto-generated method stub
	}

	protected void retrieveGridRecords() {
		getAllClaims();
	}

	protected void displayGridRecords() {
		try {
			if (claim_dtos != null)
				numberofelements = claim_dtos.size();

			// update Selected label e.g "0 of 50 selected"
			display.setNumberOfElements(numberofelements);
			display.setPageNumber(pagenumber);
			display.refreshStatusBar();

			// enable/disable the pagination widgets
			if (pagenumber == 1) {
				display.getStatusBar().getResultSetFirstButton().disable();
				display.getStatusBar().getResultSetPreviousButton().disable();
			}

			// enable/disable the pagination widgets
			if (numberofelements < maxresults) {
				display.getStatusBar().getResultSetNextButton().disable();
			} else {
				display.getStatusBar().getResultSetNextButton().enable();
			}

			// pass the result set to the View
			if (claim_dtos != null)
				display.setResultSet(claim_dtos);
		} catch (Exception e) {
			Log.error(e.getLocalizedMessage(), e);
		}
	}


	@Override
	public void onResultSetFirstButtonClicked() {
		firstresult = 0;
		pagenumber = 1;

		retrieveGridRecords();
	}

	@Override
	public void onResultSetNextButtonClicked() {
		firstresult += numberofelements;
		pagenumber++;

		retrieveGridRecords();
	}

	@Override
	public void onResultSetPreviousButtonClicked() {
		firstresult -= maxresults;
		pagenumber--;

		retrieveGridRecords();
	}

	@Override
	public void onRefreshButtonClicked() {
		retrieveGridRecords();
	}

	protected void getAllClaims() {
		Command cmd = new Command() {

			@Override
			public void execute() {
				//Integer bill_id, Integer house_unit_id, String month, Integer year
				/*rpcservice
						.getAllWaterBills(0,0,null,0, null,new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
								eventbus, this, constants) {

							@SuppressWarnings("unchecked")
							@Override
							public void onSuccess(
									StandardServerResponse response) {

								if (response != null) {
									if (response.isSuccess()) {
										numberofelements = response
												.getIntegerData();
										if (response.getListData() != null) {
											claim_dtos = (List<Claim>) response
													.getListData();
										}
									} else {
										SC.say("Error: "+ response.getErrorData());
										return;
									}
								} else {
									SC.say("Error get all claims");
									return;
								}
								// allservices_loaded = true;
								if (claim_dtos != null) {
									displayGridRecords();
								}
							}

						});*/
			}
		};

		cmd.execute();
	}

	
	

	//public static native String removeBillForm() /*-{ return $wnd.removeBillForm(); }-*/;
	
	public static native String encodeBase64(String string) /*-{ return $wnd.btoa(string); }-*/;

	@Override
	public void onRecordDoubleClicked(Integer recordId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onNewButtonClicked() {
		// TODO Auto-generated method stub
		
	}

	
}
