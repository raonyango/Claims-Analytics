package com.analytics.client;

import net.customware.gwt.presenter.client.EventBus;
import net.customware.gwt.presenter.client.Presenter;
import net.customware.gwt.presenter.client.place.PlaceManager;

import com.analytics.client.gin.MajiGinjector;
import com.analytics.client.presenter.BillPresenter;
import com.google.gwt.user.client.ui.HasWidgets;

/**
 * @author Rosemary A. Onyango For history management and view transition logic
 */
public class AppController{
	private EventBus eventbus = null;
	private MajiGinjector binjector;	
	//private ClientUtils clientutils;
	
	/* @Inject */
	public AppController(MajiGinjector minjector,
		GreetingServiceAsync rpcservice) {
		this.binjector = minjector;
		//this.constants = binjector.getBrainupConstants();
		this.eventbus = minjector.getEventBus();
	}	

	public void go(final HasWidgets container) {
		bind();
		Presenter presenter = binjector.getMainPresenter();		
		//Presenter presenter = binjector.getProfilePresenter();
		if (presenter != null){ 
			//container.add(((HomePresenter) presenter).getDisplay().asWidget()); //if not using smartgwt
			((BillPresenter) presenter).getDisplay().asWidget().draw(); //only when using smartgwt. Else use commented line above
			presenter.bind();
		}
		
		// Load PlaceManager so it can start listening
		PlaceManager bplacemanager = binjector.getPlaceManager();
		bplacemanager.fireCurrentPlace();			
	}

	public void bind() {
		// -----------------------------------------------------------------------------------
		// EVENTBUS HANDLERS
		// -----------------------------------------------------------------------------------
		/*eventbus.addHandler(ErrorEvent.TYPE, new ErrorEventHandler() {

			@Override
			public void onNewError(ErrorEvent event) {
				clientutils.showErrorMessage(event.getTitle(), event.getMessage());				
			}

		});*/
	
		// -----------------------------------------------------------------------------------
		// BROWSER HANDLERS
		// -----------------------------------------------------------------------------------

		/*
		 * Window.addWindowClosingHandler(new ClosingHandler() {
		 * 
		 * @Override public void onWindowClosing(ClosingEvent event) { //clean
		 * up sessions eventbus.fireEvent(new InvalidateCometEvent());
		 * eventbus.fireEvent(new InvalidateSessionEvent()); } });
		 */

	}
}
