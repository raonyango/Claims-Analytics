package com.analytics.client.gin;

import net.customware.gwt.presenter.client.DefaultEventBus;
import net.customware.gwt.presenter.client.gin.AbstractPresenterModule;
import net.customware.gwt.presenter.client.place.ParameterTokenFormatter;
import net.customware.gwt.presenter.client.place.TokenFormatter;

import com.analytics.client.place.BillPlace;
import com.analytics.client.presenter.BillPresenter;
import com.analytics.client.view.BillView;
import com.google.inject.Singleton;

public class MajiClientGinModule extends AbstractPresenterModule {

	@Override
	protected void configure() {		
		bind(TokenFormatter.class).to(ParameterTokenFormatter.class);
				
		bind(net.customware.gwt.presenter.client.EventBus.class).to(DefaultEventBus.class).in(Singleton.class);
		bindPresenter(BillPresenter.class, BillPresenter.IBillViewDisplay.class, BillView.class);
		
		bind(BillPlace.class).in(Singleton.class);
        //bind(EventBus.class).to(SimpleEventBus.class).in(Singleton.class);
		//bind(BrainupPlaceFactory.class).in(Singleton.class);
		//bind(ActivityMapper.class).to(BrainupActivityMapper.class).in(Singleton.class);
		//bind(PlaceController.class).to(InjectablePlaceController.class);
		//bind(BrainupServiceAsync.class);		
		//bind(AppController.class).in(Singleton.class);		
	}
}
