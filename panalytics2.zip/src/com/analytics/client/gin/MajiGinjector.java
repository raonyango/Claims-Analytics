package com.analytics.client.gin;

import com.analytics.client.presenter.BillPresenter;
import com.google.gwt.inject.client.GinModules;
import com.google.gwt.inject.client.Ginjector;

import net.customware.gwt.presenter.client.EventBus;
import net.customware.gwt.presenter.client.place.PlaceManager;

@GinModules(MajiClientGinModule.class)
public interface MajiGinjector extends Ginjector {
	EventBus getEventBus();
	//BrainupPlaceFactory getPlaceFactory();
	//ActivityMapper getActivityMapper();
	//PlaceController getPlaceController();	
	
	PlaceManager getPlaceManager();
		
	BillPresenter getMainPresenter();

	
}
