package com.analytics.client.view.uihandlers;



public interface BillViewUiHandlers extends UiHandlers{

	void onRecordDoubleClicked(Integer recordId);

	void onResultSetFirstButtonClicked();

	void onResultSetPreviousButtonClicked();

	void onResultSetNextButtonClicked();

	void onRefreshButtonClicked();

	void onNewButtonClicked();

}
