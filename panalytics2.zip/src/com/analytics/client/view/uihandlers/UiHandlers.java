package com.analytics.client.view.uihandlers;

public interface UiHandlers {

}
